# 3D ULPIN — City Studio

A separate, self-contained interactive district built around the supplied 3D property-map mockups. This project does not read or modify the existing `3d-ulpin` repositories or databases.

## Start on this computer

```powershell
cd E:\Projects\ulpin-city-studio
npm run dev
```

Open **http://127.0.0.1:5175**. The current session already has the development server running on this port. A second server will refuse to start instead of silently choosing another port.

For a clean checkout or another computer:

```powershell
cd path\to\ulpin-city-studio
npm ci
npm run dev
```

Node.js 24 was used for this build. Chrome or Edge with WebGL 2 and hardware acceleration is recommended. There is no database setup, Docker requirement, Cesium token, map API key, or external tile service. Installed dependencies are pinned by `package-lock.json`.

## What is here

The **832 × 832 metre synthetic district** contains **944 individually selectable buildings**, 944 linked rectangular parcels, 5 parks, 18 road corridors and 36 utility segments. Every building has a unique 14-digit **demo** reference, an owner fixture, a floor schedule and two occupancy records per floor.

The map uses actual 3D geometry: window reveals, glazing, floor bands, projecting balconies, parapets, stair housings, roof tanks, solar panels, roads, markings, crossings, cars, trees, paths and fountains. The right-hand thumbnail is captured from the live scene. It is not a pasted mockup. Terrain and leaf textures are generated locally; there are no stock-image or external-asset dependencies.

### Map controls

| Action | Control |
| --- | --- |
| Pan | Left-button drag |
| Orbit / tilt | Right-button drag |
| Zoom | Mouse wheel or + / − |
| Inspect a property | Click a building, parcel, property-list row, or minimap footprint |
| Find by identifier, address, owner or occupant | Header search; Ctrl/Cmd + K focuses it |
| View all 944 buildings | **Fit district** |
| Return to the selected neighbourhood | **Fit block** |
| Inspect a close-up | Crosshair / **Focus selected building** |
| See a cadastral-style plan | **2D**, then switch Buildings off |
| See buried networks | **Underground**, then enable water / sewer / electric layers |
| Inspect interiors | Inspector → **Floors** → **Explode floors**, or select one floor |
| Expand the map | Maximise button hides the side panels; click again to restore |

### Repeatable showcase

1. Search for **11007500003527**, the Lake View Residence at 12, Lake View Road.
2. Inspect its parcel and overview. The computed footprint difference is **32 m²**; its road intersection is **16 m²**.
3. Open **Utilities**. The nearest water pipe is **1.8 m horizontally from the footprint**, with its centre **2.6 m below grade**. These are different measurements.
4. Open **Floors**, explode the building and select individual levels.
5. Open the **register**. Each unit has a fictional occupant, occupancy status, area and, where rented, sample rent and lease dates.
6. Inspect a rent agreement, land record or floor plan, and download the PDF.
7. Open **Overview** for the entire district's aerial-style diagram, then download its PDF.
8. Choose **Fit district** to explore the wider area. **Check** recomputes district findings; **Findings** filters them by category.

### Exports

The Export dialog produces a complete linked JSON dataset, a 944-parcel GeoJSON, a district overview PDF, and an image of the current map camera view. Record dialogs also produce land-record, rental-occupancy, floor-plan and complete-register PDFs. Documents visibly identify themselves as synthetic specimens and include no official seals, signatures or real identity numbers.

## Data and geometry truth

**Everything is synthetic.** The number field is a 14-digit demo identifier, **not an officially issued ULPIN**. Owners, tenants, land records and rental documents are fictional. The model is not a scan of Delhi, a cadastral survey, photogrammetry, drone imagery, or evidence of actual ownership. The visual direction follows the supplied mockups, but it is not a pixel-identical recreation of their photorealistic rendering.

Internal coordinates are local planar metres: X is east, negative Z is north, and Y is elevation. Building height is floor count × 3.2 m, plus separately modelled roof details. Exploded floors are visually separated for inspection; their listed real model elevations remain unchanged. Pipes use actual negative Y coordinates in underground mode; their displayed thickness is exaggerated for readability.

GeoJSON uses a clearly labelled, approximate synthetic placement around 28.62 N, 77.05 E, converted from the local coordinates. That placement is **not surveyed** and must not be interpreted as real Delhi property boundaries.

Findings are deterministic geometry calculations, not prewritten metrics:

- Parcel finding: footprint area minus footprint/parcel intersection area.
- Road finding: footprint/road-corridor rectangle intersection area.
- Utility finding: shortest horizontal footprint-to-pipe-surface distance below a **2 m demonstration threshold**. This threshold is not a legal or municipal rule.

For the default building, the 16 m² road overlap lies within its 32 m² parcel-overhang area. **Do not add these two figures as if they were disjoint conflict areas.** Floors and interior layouts are generated inspection fixtures, not automatically recovered from a 2D parcel or approved building plan.

The aerial document is an orthographic vector overview generated from the same district geometry, **not an actual aerial photograph**.

## Architecture

```text
src/data/district.ts     Seeded geometry, linked records, findings and GeoJSON
src/scene/CityScene.tsx  Three.js / React Three Fiber scene and camera controls
src/App.tsx             Workspace, search, layers, navigation and export UI
src/components/         Inspector, register, evidence viewer, SVG diagrams
src/data/documents.ts   Browser-generated PDF specimens and download helpers
tests/                  Data invariants and browser integration checks
qa/                     Screenshots, downloaded samples and test results
```

Rendering uses instanced meshes and distance-based facade detail rather than one full React component tree per building feature. Distant district views keep the building masses while nearby views resolve windows, balconies and rooftop equipment. The viewer needs no PostGIS, Shapely or Cesium backend for this synthetic local inspection use case. There is no hidden claim of live government integration, authentication, document upload, permanent edits, or automatic legal registration. Reloading restores the deterministic demo.

## Build and test

```powershell
npm run build
npm test
node tests/browser-integration.mjs
```

The browser integration script expects the application to be running on port 5175 and an installed Google Chrome. It clicks the actual application, checks camera/selection/layer/floor/register interactions, downloads the files, and saves evidence under `qa/`. It does not interact with your other projects.

The optional `tests/render-pdfs.py` uses a project-local PyMuPDF installation in `.qa-python` to render exported sample PDFs for visual review. This is QA tooling only and is not needed to run the app.

Production preview:

```powershell
npm run build
npm run preview
```

Stop the existing port-5175 development server before running the production preview on the same port.
