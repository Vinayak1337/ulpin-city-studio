import { Building2, X, MapPin, Layers3, ChevronRight, FileText, TriangleAlert, Expand, ArrowUpRight, Droplets, Users, Box, Landmark, History, Check, Network } from 'lucide-react';
import type { Building, Finding, InspectorTab, ModalKind } from '../types';
import { district, utilityClearance } from '../data/district';
import { BuildingPreview, FloorPlan } from './Visuals';
import './inspection.css';
type Props={building:Building;findings:Finding[];tab:InspectorTab;onTab:(t:InspectorTab)=>void;onClose:()=>void;onFocus:()=>void;onModal:(k:ModalKind)=>void;onFloor:(f:number|null)=>void;onExplode:()=>void;exploded:boolean;floor:number|null;preview?:string};
export default function Inspector({building:b,findings,tab,onTab,onClose,onFocus,onModal,onFloor,onExplode,exploded,floor,preview}:Props){
  const closest=district.utilities.filter(u=>u.kind==='Water').map(u=>({u,d:utilityClearance(b,u)})).sort((a,c)=>a.d-c.d)[0];
  const vacant=b.units.filter(u=>u.tenure==='Vacant').length;
  return <aside className="inspector" aria-label="Property inspector">
    <div className="ins-heading"><strong><Building2 size={16}/> Building</strong><div><button className="icon-button" title="Focus selected building" onClick={onFocus}><Expand size={15}/></button><button className="icon-button" title="Close inspector" onClick={onClose}><X size={17}/></button></div></div>
    <div className="ins-scroll">
      <div className="ins-preview">{preview?<img className="building-preview" src={preview} alt={`Live scene view of ${b.name}`}/>:<BuildingPreview b={b}/>}<span className={`ins-preview-status ${findings.length?'alert':''}`}>{findings.length?<TriangleAlert size={12}/>:<Check size={12}/>} {findings.length?`${findings.length} computed findings`:'No geometry findings'}</span><button onClick={onFocus} className="ins-preview-focus" title="Focus building on map"><Expand size={14}/></button></div>
      <div className="ins-identity"><span className="ins-eyebrow">DEMO ULPIN · 14 DIGITS</span><h2 data-testid="selected-ulpin">{b.ulpin}</h2><p className="ins-building-name">{b.name}</p><p><MapPin size={13}/>{b.address}</p><div className="ins-badges"><span><Building2 size={12}/>{b.use}</span><span><Layers3 size={12}/>G+{b.floors-1}</span><span className="green"><i/>Modelled</span></div></div>
      <nav className="ins-tabs" aria-label="Inspector tabs">{(['overview','parcel','floors','evidence','utilities'] as InspectorTab[]).map(t=><button className={tab===t?'active':''} key={t} onClick={()=>onTab(t)}>{t==='floors'?'Floors':t[0].toUpperCase()+t.slice(1)}</button>)}</nav>
      <div className="ins-content">
        {tab==='overview'&&<>
          <div className="ins-metrics"><div><span>Footprint</span><strong>{b.width*b.depth} <small>m²</small></strong></div><div><span>Floors / units</span><strong>{b.floors} / {b.units.length}</strong></div><div><span>Parcel area</span><strong>{b.parcel.width*b.parcel.depth} <small>m²</small></strong></div></div>
          {findings.length>0&&<div className="ins-alert"><TriangleAlert size={18}/><div><span>Footprint outside recorded parcel</span><strong>{findings.find(f=>f.type==='Parcel')?.value||0} m²</strong></div><span className="ins-tiny-pill">Computed</span></div>}
          <div className="ins-section-title"><h3>Linked property records</h3><span className="ins-count">{b.units.length+2}</span></div>
          <button className="ins-link-row" onClick={()=>onTab('parcel')}><span className="ins-tile"><Landmark size={16}/></span><div><strong>Land & parcel record</strong><small>{b.parcelId} · {b.owner}</small></div><ChevronRight size={15}/></button>
          <button className="ins-link-row" onClick={()=>onTab('floors')}><span className="ins-tile"><Users size={16}/></span><div><strong>Floor-wise occupancy</strong><small>{b.units.length-vacant} occupied · {vacant} vacant units</small></div><ChevronRight size={15}/></button>
          <button className="ins-link-row" onClick={()=>onModal('documents')}><span className="ins-tile"><FileText size={16}/></span><div><strong>Evidence & documents</strong><small>Land record, floor plans & rental records</small></div><ChevronRight size={15}/></button>
          <div className="ins-section-title"><h3>Findings <span>({findings.length})</span></h3><span>Geometry checks</span></div>
          {findings.length?findings.map(f=><button key={f.id} className={`ins-finding ${f.type==='Utility'?'utility':''}`} onClick={()=>{if(f.type==='Utility')onTab('utilities');else onTab('parcel');}}><span className="ins-finding-icon">{f.type==='Utility'?<Droplets size={15}/>:<TriangleAlert size={15}/>}</span><span>{f.title}</span><strong>{f.value} {f.unit}</strong><ChevronRight size={13}/></button>):<div className="ins-ok"><Check size={16}/>Footprint is inside this demo parcel.</div>}
          <div className="ins-provenance"><Check size={14}/><div><strong>Consistent linked demo data</strong><p>Map, floor register and documents share the same building and parcel identifiers.</p></div></div>
        </>}
        {tab==='parcel'&&<>
          <div className="ins-section-title"><h3>Parcel & land details</h3><Landmark size={16}/></div>
          <dl className="ins-details">{[['Parcel ID',b.parcelId],['Demo ULPIN',b.ulpin],['Survey reference',b.surveyNumber],['Owner (fictional)',b.owner],['Land use',b.use],['Tenure','Freehold (demo)'],['Parcel area',`${b.parcel.width*b.parcel.depth} m²`],['Footprint',`${b.width*b.depth} m²`],['Gross floor area',`${b.width*b.depth*b.floors} m²`],['Model height',`${b.height.toFixed(1)} m`],['Record date',b.registeredOn]].map(([l,v])=><div key={l}><dt>{l}</dt><dd>{v}</dd></div>)}</dl>
          <button className="ins-wide-button" onClick={()=>onModal('documents')}><FileText size={15}/>Inspect land record<ArrowUpRight size={14}/></button>
          <div className="ins-note">Parcel coordinates use local metres. The 14-digit number is a demo reference, not an issued ULPIN. Ownership is fictional.</div>
        </>}
        {tab==='floors'&&<>
          <div className="ins-section-title"><h3>Floors & units</h3><span>{b.units.length} units</span></div>
          <div className="ins-floor-actions"><button onClick={onExplode} className={exploded?'active':''}><Layers3 size={15}/>{exploded?'Collapse floors':'Explode floors'}</button><button onClick={()=>onFloor(null)}>Show all</button></div>
          {Array.from({length:b.floors},(_,i)=>b.floors-1-i).map(f=><div key={f} className={`ins-floor ${floor===f?'active':''}`}><button className="ins-floor-heading" onClick={()=>onFloor(f)}><Layers3 size={15}/><strong>{f===0?'Ground floor':`Floor ${f}`}</strong><span>+{(f*3.2).toFixed(1)} m</span><ChevronRight size={14}/></button>{b.units.filter(u=>u.floor===f).map(u=><button className="ins-unit" key={u.id} onClick={()=>onModal('register')}><div><strong>Unit {u.number}</strong><small>{u.occupant}</small></div><span className={u.tenure==='Vacant'?'vacant':'occupied'}>{u.tenure==='Rented'?'Rented':u.tenure==='Vacant'?'Vacant':'Owner'}</span></button>)}</div>)}
          <p className="ins-note">Click a floor to cut away the building. All interiors and residents are synthetic fixtures.</p>
        </>}
        {tab==='evidence'&&<>
          <div className="ins-section-title"><h3>Evidence & documents</h3><span>Demo sources</span></div>
          {[['Land record & parcel map','Ownership reference and 2D boundary',Landmark],['Floor plans','Ground through top floor',Layers3],['Occupancy & rent agreements','Unit-linked fictional residents',Users],['District aerial overview','Entire 832 × 832 m district',MapPin]].map(([title,sub,Icon],i)=>{const I=Icon as typeof FileText;return <button className="ins-link-row" key={String(title)} onClick={()=>onModal(i===3?'aerial':'documents')}><span className="ins-tile"><I size={17}/></span><div><strong>{String(title)}</strong><small>{String(sub)}</small></div><ArrowUpRight size={14}/></button>;})}
          <div className="ins-plan-preview" onClick={()=>onModal('documents')}><FloorPlan b={b} floor={floor||0}/></div>
          <div className="ins-section-title"><h3>Fixture history</h3><History size={15}/></div><div className="ins-history"><p><i/>Parcel record created<span>12 Jun 2025</span></p><p><i/>Occupancy fixtures linked<span>01 Apr 2026</span></p><p><i/>Geometry checks computed<span>This session</span></p></div>
        </>}
        {tab==='utilities'&&<>
          <div className="ins-section-title"><h3>Nearest water asset</h3><Droplets size={17}/></div>
          <dl className="ins-details">{[['Asset ID',closest.u.id],['Network',closest.u.operator],['Diameter',`${closest.u.diameter} mm`],['Centre depth',`${closest.u.depth} m below grade`],['Horizontal clearance',`${closest.d} m`],['Road corridor','12 m (synthetic)'],['Demo review threshold','2 m (not a regulation)']].map(([l,v])=><div key={l}><dt>{l}</dt><dd>{v}</dd></div>)}</dl>
          <div className="ins-section-diagram"><svg viewBox="0 0 280 143" role="img" aria-label="Pipeline depth section"><rect width="280" height="143" fill="#eaf0eb"/><path d="M0 42H280V143H0Z" fill="#b0a087"/><path d="M0 42H280V143H0Z" fill="none" stroke="#9b896e" strokeWidth="2"/><rect x="28" y="5" width="72" height="61" fill="#c7c9bd" stroke="#bd7660"/><path d="M196 43V108" stroke="#fff" strokeDasharray="3 3"/><circle cx="196" cy="111" r="14" fill="#2779a9" stroke="#afd9ed" strokeWidth="5"/><text x="206" y="78" fill="#fff" fontSize="13">2.6 m</text><text x="12" y="32" fontSize="10" fill="#5c6960">Ground level</text><text x="11" y="132" fontSize="9" fill="#fff">Illustrative section · not to scale</text></svg></div>
          <div className="ins-note"><Network size={15}/>Underground mode shows the utility fixtures at negative Y elevations below the ground surface. Horizontal distance and burial depth are different measurements.</div>
        </>}
      </div>
    </div>
    <div className="ins-footer"><button onClick={()=>onModal('register')}><FileText size={15}/>Open register</button><button onClick={()=>{onTab('floors');onExplode();onFocus();}}><Box size={15}/>Inspect floors</button><p>All identities & records are synthetic.</p></div>
  </aside>;
}
