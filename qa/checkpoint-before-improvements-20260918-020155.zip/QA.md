# Verification record

Verified locally in Chrome with Playwright. Final browser run: **2026-09-17 18:32 UTC** (18 September, 00:02 IST). The machine-readable result is `qa/browser-results.json`.

## Results

- **Production build passed:** `npm run build`.
- **7 data-integrity tests passed:** `npm test`.
- **15 browser-check groups passed**, plus exported dataset totals were asserted.
- **No page errors or console errors** were captured in the final browser run. Upstream Three.js can emit a non-blocking `Clock` deprecation warning in development; this is not an application exception.
- The final measured default neighbourhood render contained **797,444 submitted triangles and 79 draw calls**. This is one captured frame, not a claimed frame-rate guarantee. Distance-based detail selection reduced work from the initial all-facades rendering approach.
- The downloaded PDF specimens were rendered with PyMuPDF, their text was checked for page-boundary overflow, and every page carried the synthetic/legal-record disclaimer. Representative rendered agreement, floor-plan and aerial pages were visually inspected.

## Dataset totals checked from the actual downloaded JSON

| Item | Count |
| --- | ---: |
| Buildings | 944 |
| Linked parcels | 944 |
| Unit occupancy records | 8,454 |
| Parks | 5 |
| Road corridors | 18 |
| Utility segments | 36 |
| Computed findings | 24 |
| Buildings with findings | 17 |

## Browser checks

1. Initial WebGL scene, selected 14-digit identifier and computed 32 / 16 / 1.8 values.
2. A real canvas click on the projected geometry of `BLD-0414` selected its exact linked identifier, `11007510000414`.
3. Header search restored the showcase property by its full demo identifier and moved the camera.
4. Top-down 2D view and the Buildings visibility switch.
5. Entire-district camera fit, then return to the selected neighbourhood.
6. Underground mode and all three network switches.
7. Exploded floors, floor 3 selection and return to a complete building.
8. A ten-unit building register, tenant document inspection and an actual downloaded rent-agreement PDF.
9. Floor-plan selection and actual floor-plan / complete-register PDF downloads.
10. Whole-district overview and downloaded aerial-style PDF.
11. Downloaded complete JSON, 944-feature GeoJSON and actual scene PNG; file contents/signatures were checked.
12. Recomputed district findings and the Road category filter. Its row count was compared with the exported calculations rather than assumed to be one.
13. Empty search state, exact property search and recovery.
14. Desktop layout at both 1680 × 1000 and 1280 × 800 with no document-level overflow.
15. No runtime page/console errors during the completed run.

## Rendering and development fixes made during verification

An instancing visibility condition initially hid ownerless scene objects; trees, cars and street elements now remain visible. Underground rendering was changed to an explicit below-grade grid plus ghosted building outlines so the three networks are legible. The Windows development watcher excludes generated QA files, logs and local Python dependencies, avoiding an `EBUSY` failure while a downloaded JSON was being written. Explicit PCF shadow configuration avoids the removed PCFSoftShadowMap setting.

## Scope and limits

This is a functioning synthetic inspection prototype, not photogrammetry, surveyed parcel geometry or an official registry. Layout and visual direction follow the supplied mockups, but the scene is not a pixel-exact photorealistic reproduction. Floor layouts and lease records are fixtures, not inferred legal facts. The overview is a generated diagram rather than captured aerial imagery.

The production bundler emits an informational size warning for the approximately 1.62 MB main 3D/PDF bundle (approximately 470 KB gzip). Build completion is successful. No backend, user accounts, real-document ingestion, permanent editing or government integration is claimed. Mobile interaction and every browser/GPU combination have not been certified by this desktop QA run.
