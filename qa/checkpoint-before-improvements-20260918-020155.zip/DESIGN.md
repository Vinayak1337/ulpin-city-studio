# Visual contract

## Reference and scope

The supplied block-map and property-register mockups determine the composition: a quiet white/forest-green municipal workspace around a dominant oblique 3D map. Left-side layers and linked properties; right-side inspector; floating camera controls, minimap and compact computed-findings tray. Record and evidence screens retain the same visual language.

This is an independent project, not a modification of the existing 3D ULPIN implementation. The broad image pack includes other product screens; this build prioritises the map and associated inspection flow rather than pretending to implement every administration screen in the pack.

## Map

- Real orbitable orthographic scene, not an image backdrop.
- Dense, low-rise residential blocks with varied heights and warm concrete finishes.
- Visible facade frames, window recesses, balconies, roof parapets, tanks and panels.
- Fine parcel lines and clear street crossings; selected geometry uses a warm coral overlay.
- Locally generated greenery and terrain textures; no external imagery or network tile dependencies.
- Default southwest oblique camera shows the selected building beside the park and road.
- Separate district and neighbourhood camera scales. Floors can be cut away or exploded.
- Utility elevations are real negative model Y values, with visually exaggerated stroke widths.

## Inspection

The displayed identifier, parcel, footprint, floor schedule, tenants, documents and findings must come from one selected building object. No unrelated thumbnail, hardcoded owner panel or fixed finding count may masquerade as that selection. The inspector thumbnail comes from the live rendered scene, with an illustrative fallback only when a scene crop is unavailable.

## Integrity

Numeric demo identifiers must remain strings. Do not rebrand generated records as official ULPINs. Every exported legal-looking record must carry a synthetic disclaimer. The aerial-style sheet must explicitly say it is a generated diagram, not captured imagery. Geometry-derived demo checks are not legal compliance decisions.

## UI rules

White surfaces, small consistent corners, fine green-grey borders, restrained accent colours, compact icon labels, clear selection states and functional visible controls. Long identifiers must remain readable. Modal and inspector content scroll independently from the map. Preserve the scene's available width at desktop sizes; collapse side navigation where appropriate.
