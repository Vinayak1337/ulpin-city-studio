import { chromium, expect } from '@playwright/test';
import fs from 'node:fs';
import path from 'node:path';

fs.mkdirSync('qa',{recursive:true});
const browser=await chromium.launch({channel:'chrome',headless:true});
const page=await browser.newPage({viewport:{width:1680,height:1000},deviceScaleFactor:1,acceptDownloads:true});
page.setDefaultTimeout(45000);
const errors=[],results=[];
page.on('pageerror',e=>errors.push(e.message));
page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
const settle=()=>page.waitForTimeout(1600);
const step=async(name,fn)=>{await fn();results.push({name,passed:true});console.log('PASS:',name);};
const screenshot=name=>page.screenshot({path:`qa/${name}.png`,fullPage:true,timeout:60000});
const inspector=page.locator('.inspector');
const close=async()=>{await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);};
const download=async(button,name)=>{const wait=page.waitForEvent('download');await button.click();const file=await wait;await file.saveAs(path.resolve('qa',name));return fs.readFileSync(path.resolve('qa',name));};

try{
  await page.goto('http://127.0.0.1:5175',{waitUntil:'networkidle',timeout:60000});
  await page.waitForFunction(()=>window.__CITY_RENDERER__?.buildings===944);
  await page.waitForTimeout(3500);
  await step('initial 3D scene and linked 14-digit selection',async()=>{
    await expect(page.getByTestId('selected-ulpin')).toHaveText('11007500003527');
    await expect(page.locator('.findings-dock')).toContainText('32');
    await expect(page.locator('.findings-dock')).toContainText('16');
    await expect(page.locator('.findings-dock')).toContainText('1.8');
    const p=await page.evaluate(()=>window.__CITY_RENDERER__);expect(p.triangles).toBeGreaterThan(100000);
    await screenshot('01-initial');
  });
  await step('real canvas raycast selects another building',async()=>{
    const point=await page.evaluate(()=>window.__CITY_PROJECT__('BLD-0414'));
    expect(point).toBeTruthy();await page.mouse.click(point.x,point.y);await page.waitForTimeout(300);
    const id=await page.getByTestId('selected-ulpin').innerText();expect(id).toBe('11007510000414');
    expect(id).toMatch(/^\d{14}$/);
  });
  await step('global ULPIN search and camera focus',async()=>{
    await page.getByRole('textbox',{name:'Search ULPIN, property or owner',exact:true}).fill('11007500003527');
    await page.getByRole('textbox',{name:'Search ULPIN, property or owner',exact:true}).press('Enter');
    await expect(page.getByTestId('selected-ulpin')).toHaveText('11007500003527');await settle();
    await page.getByRole('textbox',{name:'Search ULPIN, property or owner',exact:true}).fill('');await page.keyboard.press('Escape');
  });
  await step('2D parcel map and layer visibility',async()=>{
    await page.getByRole('button',{name:'2D',exact:true}).click();await settle();
    await page.getByRole('switch',{name:'Buildings',exact:true}).click();
    await expect(page.getByRole('switch',{name:'Buildings',exact:true})).toHaveAttribute('aria-checked','false');
    await screenshot('02-2d-parcels');
    await page.getByRole('switch',{name:'Buildings',exact:true}).click();
    await page.getByRole('button',{name:'3D',exact:true}).click();await settle();
  });
  await step('fit complete district and return to neighbourhood',async()=>{
    await page.getByTestId('fit-district').click();await settle();
    expect(await page.evaluate(()=>window.__CITY_RENDERER__.zoom)).toBeLessThan(1);
    await screenshot('03-entire-district');
    await page.getByRole('button',{name:'Fit block',exact:true}).click();await settle();
    expect(await page.evaluate(()=>window.__CITY_RENDERER__.zoom)).toBeGreaterThan(5);
  });
  await step('underground water sewer and power layers',async()=>{
    await page.getByRole('button',{name:'Underground',exact:true}).click();
    await page.getByRole('switch',{name:'Sewer network',exact:true}).click();
    await page.getByRole('switch',{name:'Electric cables',exact:true}).click();await settle();
    await expect(page.locator('.underground-banner')).toBeVisible();await screenshot('04-underground');
    await page.getByRole('button',{name:'Underground',exact:true}).click();
    await page.getByRole('switch',{name:'Sewer network',exact:true}).click();
    await page.getByRole('switch',{name:'Electric cables',exact:true}).click();
  });
  await step('exploded floors and cutaway selection',async()=>{
    await inspector.getByRole('button',{name:'Floors',exact:true}).click();
    await inspector.getByRole('button',{name:'Explode floors',exact:true}).click();
    await inspector.getByRole('button',{name:'Focus selected building',exact:true}).click();await settle();
    await expect(page.locator('.floor-toolbar')).toContainText('Exploded floors');
    await screenshot('05-exploded-floors');
    await page.locator('.floor-toolbar').getByRole('button',{name:'3',exact:true}).click();
    await expect(page.locator('.ins-floor.active')).toContainText('Floor 3');
    await page.getByRole('button',{name:'Return to full building',exact:true}).click();await settle();
  });
  await step('floor register and actual rent agreement PDF download',async()=>{
    await inspector.getByRole('button',{name:'Open register',exact:true}).click();
    await expect(page.getByRole('dialog')).toContainText('Floors & occupancy');
    await expect(page.locator('.rec-unit-card')).toHaveCount(10);await screenshot('06-register');
    await page.getByRole('button',{name:'Inspect rent agreement',exact:true}).first().click();
    await expect(page.locator('.rec-document')).toContainText('NOT A LEGAL OR GOVERNMENT RECORD');
    await expect(page.locator('.rec-document')).toContainText('Lease start');
    const bytes=await download(page.getByRole('button',{name:'PDF',exact:true}),'demo-rent-agreement.pdf');
    expect(bytes.subarray(0,5).toString()).toBe('%PDF-');await screenshot('07-rent-agreement');await close();
  });
  await step('floor plan PDF and full register PDF download',async()=>{
    await inspector.getByRole('button',{name:'Open register',exact:true}).click();
    let bytes=await download(page.getByRole('button',{name:'Download complete register',exact:true}),'demo-building-register.pdf');expect(bytes.subarray(0,5).toString()).toBe('%PDF-');
    await page.getByRole('button',{name:'Illustrative floor plan',exact:true}).click();
    await page.getByLabel('Floor',{exact:true}).selectOption('3');await screenshot('08-floor-plan');
    bytes=await download(page.getByRole('button',{name:'PDF',exact:true}),'demo-floor-plan.pdf');expect(bytes.subarray(0,5).toString()).toBe('%PDF-');await close();
  });
  await step('whole-area aerial overview and PDF export',async()=>{
    await page.locator('.header-actions').getByRole('button',{name:'Overview',exact:true}).click();
    await expect(page.getByRole('dialog')).toContainText('not a drone or satellite photograph');
    await screenshot('09-aerial-overview');
    const bytes=await download(page.getByRole('button',{name:'Download overview PDF',exact:true}),'demo-aerial-overview.pdf');expect(bytes.subarray(0,5).toString()).toBe('%PDF-');await close();
  });
  await step('full dataset, GeoJSON and actual map PNG downloads',async()=>{
    await page.locator('.header-actions').getByRole('button',{name:'Export',exact:true}).click();
    const data=JSON.parse((await download(page.getByRole('button',{name:/Complete linked dataset/}),'demo-district.json')).toString());
    expect(data.buildings.length).toBe(944);expect(data.utilities.length).toBe(36);expect(data.synthetic).toBe(true);
    const geo=JSON.parse((await download(page.getByRole('button',{name:/2D parcel GeoJSON/}),'demo-parcels.geojson')).toString());expect(geo.features.length).toBe(944);expect(geo.features[0].properties.synthetic).toBe(true);
    const png=await download(page.getByRole('button',{name:/Current map as PNG/}),'demo-map.png');expect(png.subarray(1,4).toString()).toBe('PNG');
    await screenshot('10-export');await close();
    results.push({name:'dataset totals',buildings:data.buildings.length,units:data.buildings.reduce((n,b)=>n+b.units.length,0),roads:data.roads.length,utilities:data.utilities.length,findings:data.findings.length,affectedBuildings:new Set(data.findings.map(f=>f.buildingId)).size,passed:true});
  });
  await step('computed district check and filterable findings',async()=>{
    await page.locator('.header-actions').getByRole('button',{name:'Check',exact:true}).click();
    await expect(page.getByRole('status')).toContainText('Checked 944 footprints');
    await page.locator('.sidebar-tabs').getByRole('button',{name:'Findings',exact:true}).click();
    await page.locator('.finding-filters').getByRole('button',{name:'Road',exact:true}).click();
    const expectedRoads=JSON.parse(fs.readFileSync('qa/demo-district.json','utf8')).findings.filter(f=>f.type==='Road').length;
    await expect(page.locator('.findings-list>button')).toHaveCount(expectedRoads);await screenshot('11-findings');
    await page.locator('.sidebar-tabs').getByRole('button',{name:'Layers',exact:true}).click();
  });
  await step('property search empty state and recovery',async()=>{
    const input=page.getByRole('textbox',{name:'Search properties in district',exact:true});await input.fill('no-such-property-xyzz');
    await expect(page.locator('.empty-message')).toBeVisible();await input.fill('11007500003527');await expect(page.locator('.property-row')).toHaveCount(1);await input.fill('');
  });
  await step('desktop layout fits 1280 x 800',async()=>{
    await page.setViewportSize({width:1280,height:800});await inspector.getByRole('button',{name:'Overview',exact:true}).click();await settle();
    const fits=await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth&&document.documentElement.scrollHeight<=window.innerHeight);expect(fits).toBe(true);await screenshot('12-desktop-1280');
    await page.setViewportSize({width:1680,height:1000});await settle();
  });
  await step('no runtime or console errors',async()=>{expect(errors).toEqual([]);});
  const summary={testedAt:new Date().toISOString(),baseURL:'http://127.0.0.1:5175',browser:'Chrome / Playwright',viewport:'1680x1000 and 1280x800',results,errors,renderer:await page.evaluate(()=>window.__CITY_RENDERER__)};
  fs.writeFileSync('qa/browser-results.json',JSON.stringify(summary,null,2));
  console.log(JSON.stringify(summary,null,2));
}catch(error){
  await screenshot('FAILURE');fs.writeFileSync('qa/browser-results.json',JSON.stringify({results,errors,failure:String(error)},null,2));console.error(error);process.exitCode=1;
}finally{await browser.close();}
